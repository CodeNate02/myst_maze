//Browser Detection
if( !document.getElementById ){
    window.location = "legacy.html";
}