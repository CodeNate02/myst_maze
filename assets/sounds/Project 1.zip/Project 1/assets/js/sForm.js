function loadForm(){
    let header = document.createElement('header'); //Generate Header
    let headerH = document.createElement('h2');     //Text inside header
    headerH.appendChild(document.createTextNode("FoodStuff - Submit")); //h2 text node
    header.appendChild(headerH);                        //Add text to header
    document.getElementsByTagName('body')[0].appendChild(header);

    startStorage();
    chosenValues="";
    
    try{
        dataStore.length;
    }
    catch{
        window.location.replace('.');
    }
    for(let i = 0; i < dataStore.length; i++){
        let box = document.createElement('div');
        box.setAttribute('class','selBox');
        let p = document.createElement('p');
        p.appendChild(document.createTextNode(dataStore[i]));
        box.appendChild(p);
        document.getElementsByTagName('body')[0].appendChild(box);
        chosenValues+=dataStore[i];
        chosenValues+="\n"
    } 
    //Build the Form
    let f = document.createElement('form');
    f.setAttribute('action','send.php');
    f.setAttribute('method',"POST");
    f.onsubmit = function(){
        if( verify( this ) ){
            setValues( this );
        }
        else{
            return false;
        }
    }
    let l1 = document.createElement('label');
    let b1 = document.createElement('input');
    l1.setAttribute('for',"Name");
    l1.appendChild(document.createTextNode('Name:  '));
    b1.setAttribute('type','text');
    b1.setAttribute('name','Name');
    b1.setAttribute('value',getStorage('fName'));
    let l2 = document.createElement('label');
    let b2 = document.createElement('input');
    l2.setAttribute('for',"Email");
    l2.appendChild(document.createTextNode('E-Mail Address:  '))
    b2.setAttribute('type','text');
    b2.setAttribute('name','Email');
    b2.setAttribute('value',getStorage('fMail'));
    let b = document.createElement('input');
    b.setAttribute('type','submit');
    b.setAttribute('value','Submit');
    f.appendChild(l1);
    f.appendChild(b1);
    f.appendChild(document.createElement('br'));
    f.appendChild(l2);
    f.appendChild(b2);
    f.appendChild(document.createElement('br'));
    f.appendChild(b);
    
    let h = document.createElement('input');
    h.setAttribute('type','hidden');
    h.setAttribute('value',chosenValues);
    h.setAttribute('name','Values');

    f.appendChild(h);

    document.getElementsByTagName('body')[0].appendChild(f);
}

function setValues( a ){
    console.log(a.getElementsByTagName('input')[0].value);
    setStorage('fName',a.getElementsByTagName('input')[0].value);
    console.log(getStorage('fName')); 
    setStorage('fMail',a.getElementsByTagName('input')[1].value); 
}