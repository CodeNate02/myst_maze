function verify( f ){
    let go = 1;
    for(let i = 0; i < f.getElementsByTagName('input').length; i++){
        if(f.getElementsByTagName('input')[i].value == ""){
            f.getElementsByTagName('input')[i].style.borderColor='red';
            go = 0;
        }
    }
    if(go != 1){
        return false;   
    }
    else{
        return true;
    }
}