//Nathan Bachelder
//Cookie Code Collection

var storage = 0;
var expDays = 1; //Number of days before cookie expiry
var dir = "/";   //Cookie path
                 //Both can be altered as the site requires

function startStorage(){
  //Cookie Check/Setup Stage
  if(testCookie() == 1){
    console.log("Cookies Enabled, Running Cookie Script");
    storage = 1;
  }
  else{ //Give LocalStorage a shot
  //    */
      try{
          if(localStorage){
              console.log("Cookies Disabled, Using localStorage");
              storage = 2;
          }
      }
      catch (e) {
          //Browsers throw an error if localStorage is blocked
          console.log("Localstorage Blocked, no storage used");
      }
  }
}
                 
function testCookie(){ //TEST IF COOKIES CAN BE SET/RETRIEVED (COMPATIBILITY STEP)
    setCookie('nTestCookie','set'); //Set a test cookie
    if( cookieExists('nTestCookie') == 1 ){ //If the cookie exists
      removeCookie('nTestCookie'); //Remove the test cookie
      return 1; //Return 1 for true
    }
    else{ //Otherwise return 0 for false
        return 0;
    }
}

function cookieExists(cookieName){ //Checks if a cookie has been set
  if( getCookie(cookieName) == "" ){ //If the cookie returns "", it's unset
    return 0;                        //Return False
  }
  else{                               //Otherwise Return true
    return 1;
  }
}

function removeCookie(cookieName){  //Removes a set cookie
  let expire = new Date(0);         //Create an expiry date at 01 Jan 1970.  Cookie is LONG expired
  document.cookie = cookieName+"=REMOVE"+"; expires="+expire.toUTCString()+"; path="+dir+";"; //Set cookie, it immediately expires
}

function setCookie(cookieName,cookieValue){ //Sets cookie
  let expD = new Date();                    //Get date
  expD.setTime(expD.getTime() + expDays*24*60*60*1000); //Cookies set will last for 1 day by default
  document.cookie=cookieName+"="+cookieValue+"; expires="+expD.toUTCString()+"; path="+dir+";"; //Sets Cookie
}

function getCookie(cookieName) { //Find a cookie
    let name = cookieName + "="; //Grab the name, plus =
    let cookieArray = document.cookie.split('; '); //Split the cookie information at '; ', returning an array of cookie=x's
    for(let i = 0; i <cookieArray.length; i++) {
      if (cookieArray[i].indexOf(name) == 0) { //Go through each one for one that starts with the name

        return cookieArray[i].slice(name.length); //Return the string with the cookie= bit sliced off
      }
    }
    return ""; //If a cookie isn't found, return "" to verify it is unset
  }

//Storage Scripts, may move these to cookie.js later for modularity
function setStorage(key, value){
  if(storage == 1){
      setCookie(key, value);
  }
  else if(storage == 2){
      localStorage.setItem(key, value);
  }
  else{
    return null;
  }
}
function getStorage(key){
  if(storage == 1){
      return getCookie(key);
  }
  else if(storage == 2 && localStorage.getItem(key)){
    return localStorage.getItem(key);
  }
  else{
    return "";
  }
}