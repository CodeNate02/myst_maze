// Nathaniel R. W. Bachelder
//Interactive Form Script

const TREELOC = "assets/trees/"; //Folder location of the tree files
const TREEFILES = ["tree.json","tree2.json"]; //Name of the tree files
var TREES = [];
var treeSel = 0;
function pageLoad(){
//
    startStorage();
    if(getStorage('tree')){
        treeSel = getStorage('tree');
    }
    else{
        setStorage('tree',0);
    }
    
    //Create Page Structure
    //Create Header
    let header = document.createElement('header'); //Generate Header
    let headerH = document.createElement('h2');     //Text inside header
    headerH.appendChild(document.createTextNode("FoodStuff")); //h2 text node
    header.appendChild(headerH);                        //Add text to header
    let headerS = document.createElement('select');     //Create selection box for tree selection
    headerS.setAttribute('id','treeSelect');            //Set ID for use in change script
    headerS.onchange = function(){ changeTree(this); };     //Fires changeTree when the value is changed
    
    //Append Header to Body
    document.getElementsByTagName('body')[0].appendChild(header);

    //Create Strutural Divs
    let formBox = document.createElement('div');
    formBox.setAttribute('id','formBox'); //Stores form elements
    

    //Append Structural Divs to Body
    document.getElementsByTagName('body')[0].appendChild(formBox);

    //Load JSON files
    let hreq = new XMLHttpRequest();
    if(!hreq){
        window.location = "legacy.html"; //Redirect for compatibility
    }

    //Load each tree file, functions as a loop until each is loaded.  Since the request is asynchronous, accounts for various load states and runs next steps as necessary
    hreq.onreadystatechange = function(){
        if(hreq.readyState == 4){                   
            //ADD OPTION TO DROPDOWN
            let tSel = document.createElement('option');
            tSel.appendChild(document.createTextNode(TREEFILES[TREES.length])); //Add name to dropdown
            headerS.appendChild(tSel);

            //LOAD RESPONSE TO TREES
            let res = hreq.responseText;            //load response text
            TREES.push(JSON.parse(res));            //Add parsed JSON array to TREES array
            
            //LOAD THE 'start' BOX immediately after the first code ever
            if(TREES.length-1 == treeSel){ //Start the loadBox ONLY when this is selected tree
                loadBox("start");
                headerS.selectedIndex=treeSel;
            }

            if(TREES.length == TREEFILES.length){   //Once all TREEFILES have been loaded, appends the selection menu to the header
                header.appendChild(headerS);
            }
            else{ //If there's still a treefile to load, load it
                hreq.open("GET",TREELOC+TREEFILES[TREES.length]); //Since the arrays start as 0, TREES.length can be used to select the NEXT value to be loaded at any given time
                hreq.send();
            }
        }
    }
    
    //Request tree files
    //Run a httprequest for each TREEFILES file 
    hreq.open("GET",TREELOC+TREEFILES[0]);
    hreq.send(); //This send begins the loop above
}

function loadBox( treeID ){
    let branch = TREES[treeSel][treeID];
    try{
        while( document.getElementById('infoBox').lastChild ){
            document.getElementById('infoBox').removeChild(document.getElementById('infoBox').lastChild);
        }
    }
    catch{}
    if(branch){
        //NEW SELECTION BOX
        let selBox = document.createElement('div');
        selBox.setAttribute('class','selBox');

        //INSERT QUESTION INTO BOX
        let q = document.createElement('p');
        q.appendChild(document.createTextNode(branch[0]+'?'));
        selBox.appendChild(q);

        //CREATE ANSWER SELECTION BOX
        let aBox = document.createElement('select');
        aBox.onchange= function(){ getChoice( this ); };

        //Default Value
        let answer = document.createElement('option');
        answer.appendChild(document.createTextNode("---"));
        aBox.appendChild(answer);

        //loop through each option and add them as an option
        for(let i=1; i < branch.length; i++){
            let answer = document.createElement('option');
            answer.appendChild(document.createTextNode(branch[i]));
            aBox.appendChild(answer);
        }
        //Insert answer box into selection box
        selBox.appendChild(aBox);

        //INSERT BOX INTO BODY
        document.getElementById('formBox').appendChild(selBox);
    }
    else{
        //Runs after the final choice has been made
        finish();
    }
}
function getChoice( src ){
    //Remove any older children
    while(document.getElementById('formBox').lastChild != src.parentElement){
        document.getElementById('formBox').lastChild.remove();
    } 
    let val = src.options[src.selectedIndex].firstChild.nodeValue;
    if(val != "---"){
        loadBox(val);
    }
}

function finish(){
    //YOU SELECTED: Header
    let youSel = document.createElement('h3');
    youSel.appendChild(document.createTextNode("You Selected:"));
    let dataStore=[];
    //OL:
    let list = document.createElement('ul');
    for(let i = 0; i < document.getElementsByClassName('selBox').length; i++){
        let currentBox = document.getElementsByClassName('selBox')[i];
        let outMessage = "";
        outMessage += currentBox.firstChild.firstChild.nodeValue.slice(0,-1);
        outMessage += ": ";
        outMessage += currentBox.lastChild.childNodes[currentBox.lastChild.selectedIndex].firstChild.nodeValue;
        dataStore.push(outMessage);
        let oM = document.createElement('li');
        oM.appendChild(document.createTextNode(outMessage));
        list.appendChild(oM);
        
        
    }
    let infoBox=document.createElement('div');
    infoBox.setAttribute('id','infoBox');
    infoBox.appendChild(youSel);
    infoBox.appendChild(list);

    //Add button
    let button = document.createElement('button');
    button.appendChild(document.createTextNode("Submit"));
    button.onclick = function(){
        formWindow = window.open("form.html");
        submitButton( formWindow, dataStore );
    }
    infoBox.appendChild(button);

    document.getElementsByTagName('body')[0].appendChild(infoBox);
}
function changeTree( sel ){
    treeSel = sel.selectedIndex; //Swap treesel to the selected value
    setStorage('tree',sel.selectedIndex)
    
    
    while( document.getElementById('formBox').lastChild ){
        document.getElementById('formBox').removeChild(document.getElementById('formBox').lastChild);
    }

    loadBox('start');
}
function submitButton( w, dS ){
    w.dataStore = dS;
}