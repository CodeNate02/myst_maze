<?php
    $chosen = $_POST['Values'];
    $email = $_POST['Email'];
    $name = $_POST['Name'];

    $email_subject = "Your FoodStuff Order";
    $email_body = "Name: $name\n";
    $email_body .= "Order: \n";
    $email_body .= "$chosen\n";

    if(mail($email, $email_subject, $email_body)){
        $sent='true';
    }
    else{
        $sent='false';
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <script>
            function kill(){
                window.close();
            }
            
        </script>
    </head>
    <body onload='kill()'> 
    <?php
    echo("$email \n");
    echo("<br>");
    echo("$email_subject \n");
    echo("<br>");
    echo("$email_body");
    echo("<br>");
    echo("$sent");
    ?>
    </body>
</html>